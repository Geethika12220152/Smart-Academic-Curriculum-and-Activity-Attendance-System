"""
EduPlatform — Academic & Sports Management System
FastAPI + SQLite backend with fingerprint integration (Mantra RD Service)
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime, timedelta
import sqlite3, os, json, xml.etree.ElementTree as ET, random, math

app = FastAPI(title="EduPlatform API", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DB = os.path.join(os.path.dirname(__file__), "..", "database", "edu.db")

# ══════════════════════════════════════════════════════════════════════════════
# DATABASE
# ══════════════════════════════════════════════════════════════════════════════

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    conn = get_db()
    c = conn.cursor()
    c.executescript("""
    -- Core
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        roll_number TEXT NOT NULL UNIQUE,
        department TEXT NOT NULL DEFAULT 'CSE',
        year INTEGER NOT NULL DEFAULT 1,
        email TEXT,
        parent_email TEXT,
        photo_url TEXT
    );

    CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        timestamp TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'class',
        event_id INTEGER,
        FOREIGN KEY (student_id) REFERENCES students(id)
    );

    -- Curriculum
    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        code TEXT NOT NULL UNIQUE,
        department TEXT NOT NULL,
        year INTEGER NOT NULL,
        total_hours INTEGER NOT NULL DEFAULT 60,
        credits INTEGER NOT NULL DEFAULT 4
    );

    CREATE TABLE IF NOT EXISTS topics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'not_started',
        sequence_order INTEGER NOT NULL DEFAULT 0,
        hours_planned INTEGER NOT NULL DEFAULT 2,
        hours_completed INTEGER NOT NULL DEFAULT 0,
        resources TEXT,
        completed_date TEXT,
        FOREIGN KEY (subject_id) REFERENCES subjects(id)
    );

    CREATE TABLE IF NOT EXISTS curriculum_versions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        version TEXT NOT NULL,
        changed_by TEXT NOT NULL DEFAULT 'Admin',
        changed_at TEXT NOT NULL,
        notes TEXT,
        FOREIGN KEY (subject_id) REFERENCES subjects(id)
    );

    CREATE TABLE IF NOT EXISTS exams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        exam_type TEXT NOT NULL,
        scheduled_date TEXT,
        auto_scheduled INTEGER NOT NULL DEFAULT 0,
        trigger_percent INTEGER NOT NULL DEFAULT 70,
        status TEXT NOT NULL DEFAULT 'upcoming',
        FOREIGN KEY (subject_id) REFERENCES subjects(id)
    );

    CREATE TABLE IF NOT EXISTS ai_suggestions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        suggestion TEXT NOT NULL,
        generated_at TEXT NOT NULL,
        applied INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (subject_id) REFERENCES subjects(id)
    );

    -- Activities & Sports
    CREATE TABLE IF NOT EXISTS activities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT,
        start_date TEXT NOT NULL,
        end_date TEXT,
        venue TEXT,
        max_participants INTEGER,
        credits INTEGER NOT NULL DEFAULT 5,
        department TEXT,
        status TEXT NOT NULL DEFAULT 'upcoming'
    );

    CREATE TABLE IF NOT EXISTS activity_registrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        activity_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        registered_at TEXT NOT NULL,
        checked_in INTEGER NOT NULL DEFAULT 0,
        checkin_time TEXT,
        result TEXT,
        performance_notes TEXT,
        credits_awarded INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (activity_id) REFERENCES activities(id),
        FOREIGN KEY (student_id) REFERENCES students(id),
        UNIQUE(activity_id, student_id)
    );

    CREATE TABLE IF NOT EXISTS parent_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        alert_type TEXT NOT NULL,
        message TEXT NOT NULL,
        sent_at TEXT NOT NULL,
        read_status INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (student_id) REFERENCES students(id)
    );

    CREATE TABLE IF NOT EXISTS engagement_scores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        score_date TEXT NOT NULL,
        attendance_score REAL NOT NULL DEFAULT 0,
        activity_score REAL NOT NULL DEFAULT 0,
        sports_score REAL NOT NULL DEFAULT 0,
        total_score REAL NOT NULL DEFAULT 0,
        UNIQUE(student_id, score_date)
    );
    """)
    conn.commit()

    # ── SEED DATA ──────────────────────────────────────────────────────────────
    c.execute("SELECT COUNT(*) FROM students")
    if c.fetchone()[0] == 0:
        _seed(conn)
    conn.close()

def _seed(conn):
    c = conn.cursor()
    today = date.today()

    # Students
    students = [
        ("Amit Sharma",      "101", "CSE", 2, "amit@college.edu",  "parent_amit@gmail.com"),
        ("Priya Verma",      "102", "CSE", 2, "priya@college.edu", "parent_priya@gmail.com"),
        ("Rohan Mehta",      "103", "ECE", 2, "rohan@college.edu", "parent_rohan@gmail.com"),
        ("Sneha Iyer",       "104", "CSE", 3, "sneha@college.edu", "parent_sneha@gmail.com"),
        ("Karthik Reddy",    "105", "ME",  2, "karthik@college.edu","parent_karthik@gmail.com"),
        ("Divya Nair",       "106", "CSE", 1, "divya@college.edu", "parent_divya@gmail.com"),
        ("Arjun Patel",      "107", "ECE", 3, "arjun@college.edu", "parent_arjun@gmail.com"),
        ("Meera Krishnan",   "108", "CSE", 2, "meera@college.edu", "parent_meera@gmail.com"),
        ("Vikram Singh",     "109", "ME",  1, "vikram@college.edu","parent_vikram@gmail.com"),
        ("Ananya Das",       "110", "CSE", 3, "ananya@college.edu","parent_ananya@gmail.com"),
    ]
    c.executemany(
        "INSERT INTO students (name,roll_number,department,year,email,parent_email) VALUES (?,?,?,?,?,?)",
        students
    )

    # Subjects
    subjects = [
        ("Data Structures & Algorithms", "CS201", "CSE", 2, 60, 4),
        ("Database Management Systems",  "CS202", "CSE", 2, 45, 3),
        ("Operating Systems",            "CS203", "CSE", 3, 60, 4),
        ("Circuit Theory",               "EC201", "ECE", 2, 45, 3),
        ("Engineering Mathematics",      "MA201", "ME",  2, 60, 4),
    ]
    c.executemany(
        "INSERT INTO subjects (name,code,department,year,total_hours,credits) VALUES (?,?,?,?,?,?)",
        subjects
    )

    # Topics for Data Structures (subject_id=1)
    dsa_topics = [
        (1, "Arrays and Strings",      "completed",    1, 6, 6,
         '{"notes":"https://notes.college/arrays","video":"https://yt.be/dsa1"}',  (today - timedelta(days=30)).isoformat()),
        (1, "Linked Lists",            "completed",    2, 6, 6,
         '{"notes":"https://notes.college/ll","video":"https://yt.be/dsa2"}',      (today - timedelta(days=20)).isoformat()),
        (1, "Stacks & Queues",         "completed",    3, 4, 4,
         '{"notes":"https://notes.college/sq","video":"https://yt.be/dsa3"}',      (today - timedelta(days=14)).isoformat()),
        (1, "Trees (Binary, BST)",     "in_progress",  4, 8, 4,
         '{"notes":"https://notes.college/trees","video":"https://yt.be/dsa4"}',   None),
        (1, "Heaps & Priority Queue",  "pending",      5, 4, 0,
         '{"notes":"https://notes.college/heaps","video":"https://yt.be/dsa5"}',   None),
        (1, "Graphs (BFS/DFS)",        "not_started",  6, 8, 0,
         '{"notes":"","video":""}', None),
        (1, "Dynamic Programming",     "not_started",  7, 10, 0,
         '{"notes":"","video":""}', None),
        (1, "Sorting Algorithms",      "completed",    8, 6, 6,
         '{"notes":"https://notes.college/sort","video":"https://yt.be/dsa8"}',    (today - timedelta(days=10)).isoformat()),
    ]
    for t in dsa_topics:
        c.execute("""INSERT INTO topics
            (subject_id,name,status,sequence_order,hours_planned,hours_completed,resources,completed_date)
            VALUES (?,?,?,?,?,?,?,?)""", t)

    # Topics for DBMS (subject_id=2)
    dbms_topics = [
        (2, "Relational Model",        "completed",   1, 4, 4, '{"notes":"","video":""}', (today-timedelta(days=25)).isoformat()),
        (2, "SQL Fundamentals",        "completed",   2, 6, 6, '{"notes":"","video":""}', (today-timedelta(days=18)).isoformat()),
        (2, "Normalization",           "in_progress", 3, 5, 3, '{"notes":"","video":""}', None),
        (2, "Transactions & ACID",     "pending",     4, 4, 0, '{"notes":"","video":""}', None),
        (2, "Indexing & Query Opt.",   "not_started", 5, 5, 0, '{"notes":"","video":""}', None),
    ]
    for t in dbms_topics:
        c.execute("""INSERT INTO topics
            (subject_id,name,status,sequence_order,hours_planned,hours_completed,resources,completed_date)
            VALUES (?,?,?,?,?,?,?,?)""", t)

    # Curriculum versions
    c.executemany(
        "INSERT INTO curriculum_versions (subject_id,version,changed_by,changed_at,notes) VALUES (?,?,?,?,?)",
        [
            (1, "v1.0", "Dr. Rajesh Kumar",  (today-timedelta(days=90)).isoformat(), "Initial curriculum"),
            (1, "v1.1", "Dr. Rajesh Kumar",  (today-timedelta(days=60)).isoformat(), "Added DP chapter"),
            (1, "v1.2", "Prof. Anita Singh", (today-timedelta(days=15)).isoformat(), "Updated Graph algorithms"),
            (2, "v1.0", "Dr. Meena Rao",     (today-timedelta(days=85)).isoformat(), "Initial"),
            (2, "v1.1", "Dr. Meena Rao",     (today-timedelta(days=20)).isoformat(), "Added NoSQL section"),
        ]
    )

    # Exams
    c.executemany(
        "INSERT INTO exams (subject_id,exam_type,scheduled_date,auto_scheduled,trigger_percent,status) VALUES (?,?,?,?,?,?)",
        [
            (1, "Unit Test 1",  (today-timedelta(days=15)).isoformat(), 0, 40, "completed"),
            (1, "Unit Test 2",  (today+timedelta(days=7)).isoformat(),  1, 70, "upcoming"),
            (1, "Mid Semester", (today+timedelta(days=20)).isoformat(), 0, 60, "upcoming"),
            (2, "Unit Test 1",  (today-timedelta(days=10)).isoformat(), 0, 40, "completed"),
            (2, "Unit Test 2",  (today+timedelta(days=14)).isoformat(), 1, 65, "upcoming"),
        ]
    )

    # AI Suggestions
    c.executemany(
        "INSERT INTO ai_suggestions (subject_id,suggestion,generated_at,applied) VALUES (?,?,?,?)",
        [
            (1, "Students struggling with Trees — recommend 2 extra practice sessions before moving to Graphs", (today-timedelta(days=5)).isoformat(), 0),
            (1, "Completion rate at 68% — auto-schedule Unit Test 2 within 7 days", (today-timedelta(days=3)).isoformat(), 1),
            (1, "Add visual animations for Linked List traversal — 3 students flagged confusion", (today-timedelta(days=1)).isoformat(), 0),
            (2, "SQL performance below target — link additional LeetCode resources", (today-timedelta(days=7)).isoformat(), 0),
        ]
    )

    # Activities
    activities = [
        ("Cricket Match — Inter-College",   "sports",        "Annual inter-college cricket tournament", (today-timedelta(days=5)).isoformat(),  (today-timedelta(days=4)).isoformat(),  "Sports Ground A", 22, 15, "CSE", "completed"),
        ("Football Tournament",             "sports",        "Intra-department football league",        (today+timedelta(days=3)).isoformat(),   (today+timedelta(days=5)).isoformat(),  "Main Ground",    30, 12, None,  "upcoming"),
        ("Coding Club — Weekly Hackathon",  "co_curricular", "Weekly 3-hour hackathon session",         (today-timedelta(days=2)).isoformat(),   (today-timedelta(days=2)).isoformat(),  "CS Lab 3",       40, 10, "CSE", "completed"),
        ("Robotics Workshop",               "co_curricular", "Build-a-bot workshop with Arduino",       (today+timedelta(days=1)).isoformat(),   (today+timedelta(days=2)).isoformat(),  "ECE Lab",        25, 12, "ECE", "upcoming"),
        ("Annual Cultural Fest — Tarang",   "cultural",      "College annual cultural festival",        (today+timedelta(days=10)).isoformat(),  (today+timedelta(days=12)).isoformat(), "Open Auditorium",200, 8,  None,  "upcoming"),
        ("Badminton Championship",          "sports",        "Intra-college badminton singles",         (today-timedelta(days=10)).isoformat(),  (today-timedelta(days=8)).isoformat(),  "Indoor Stadium",  16, 10, None,  "completed"),
        ("NSS Blood Donation Camp",         "community",     "Blood donation drive with Red Cross",     (today-timedelta(days=3)).isoformat(),   (today-timedelta(days=3)).isoformat(),  "College Lobby",  100, 20, None,  "completed"),
        ("Tech Talk — AI in Healthcare",    "co_curricular", "Guest lecture by industry expert",        (today-timedelta(days=1)).isoformat(),   (today-timedelta(days=1)).isoformat(),  "Seminar Hall",   150, 5,  None,  "completed"),
    ]
    c.executemany(
        "INSERT INTO activities (name,category,description,start_date,end_date,venue,max_participants,credits,department,status) VALUES (?,?,?,?,?,?,?,?,?,?)",
        activities
    )

    # Registrations & check-ins
    registrations = [
        # Cricket (id=1)
        (1,1,1,"Winner","Top scorer — 45 runs",15),
        (1,2,1,"Participant","Good fielding",12),
        (1,3,0,"","",0),
        (1,5,1,"Participant","",12),
        (1,8,1,"Runner-up","Took 3 wickets",13),
        # Coding Club (id=3)
        (3,1,1,"Winner","First place — AI chatbot",10),
        (3,2,1,"Participant","Built inventory system",10),
        (3,4,1,"Participant","Data visualisation project",10),
        (3,6,0,"","",0),
        (3,10,1,"Runner-up","ML model for sentiment",10),
        # Badminton (id=6)
        (6,2,1,"Winner","Undefeated — 5 matches",10),
        (6,4,1,"Participant","",10),
        (6,7,0,"","",0),
        # NSS Blood Donation (id=7)
        (7,1,1,"Volunteer","Donated blood",20),
        (7,2,1,"Volunteer","Organised queue",20),
        (7,3,1,"Volunteer","",20),
        (7,5,1,"Volunteer","",20),
        (7,8,1,"Volunteer","",20),
        # Tech Talk (id=8)
        (8,1,1,"Attendee","",5),
        (8,2,1,"Attendee","",5),
        (8,4,1,"Attendee","",5),
        (8,6,1,"Attendee","",5),
        (8,9,0,"","",0),
        # Football upcoming (id=2)
        (2,1,0,"","",0),
        (2,3,0,"","",0),
        (2,5,0,"","",0),
        (2,7,0,"","",0),
        # Robotics upcoming (id=4)
        (4,2,0,"","",0),
        (4,4,0,"","",0),
        (4,6,0,"","",0),
    ]
    for activity_id, student_id, checked_in, result, notes, credits in registrations:
        ts = datetime.now().isoformat()
        checkin_time = ts if checked_in else None
        c.execute("""INSERT OR IGNORE INTO activity_registrations
            (activity_id,student_id,registered_at,checked_in,checkin_time,result,performance_notes,credits_awarded)
            VALUES (?,?,?,?,?,?,?,?)""",
            (activity_id, student_id, ts, checked_in, checkin_time, result, notes, credits))

    # Attendance records (last 30 days)
    student_ids = list(range(1, 11))
    for days_ago in range(30, 0, -1):
        d = today - timedelta(days=days_ago)
        if d.weekday() >= 5:  # skip weekends
            continue
        for sid in student_ids:
            present = random.random() > (0.15 if sid in (1,2,4) else 0.25)
            if present:
                ts = f"{d.isoformat()} {random.randint(8,9):02d}:{random.randint(0,59):02d}:00"
                c.execute("INSERT INTO attendance (student_id,timestamp,type) VALUES (?,?,?)",
                          (sid, ts, "class"))

    # Parent alerts
    c.executemany(
        "INSERT INTO parent_alerts (student_id,alert_type,message,sent_at) VALUES (?,?,?,?)",
        [
            (1,"activity_win",   "Congratulations! Amit won the Cricket Match — Top Scorer award.", (today-timedelta(days=4)).isoformat()),
            (2,"activity_win",   "Priya won the Badminton Championship! Outstanding performance.", (today-timedelta(days=8)).isoformat()),
            (3,"absence_alert",  "Karthik missed the Coding Club session on "+( today-timedelta(days=2)).isoformat(), (today-timedelta(days=2)).isoformat()),
            (6,"absence_alert",  "Divya missed the Coding Club hackathon.", (today-timedelta(days=2)).isoformat()),
            (9,"absence_alert",  "Vikram was absent from Tech Talk session.", (today-timedelta(days=1)).isoformat()),
        ]
    )

    # Engagement scores
    _recalculate_all_engagement(conn, c)
    conn.commit()

def _recalculate_all_engagement(conn, c):
    today_str = date.today().isoformat()
    c.execute("SELECT id FROM students")
    for row in c.fetchall():
        sid = row[0]
        # Attendance score (out of 100)
        total_days = c.execute("SELECT COUNT(*) FROM attendance WHERE student_id=? AND type='class'", (sid,)).fetchone()[0]
        att_score = min(100, total_days * 5)

        # Activity score
        total_credits = c.execute(
            "SELECT COALESCE(SUM(credits_awarded),0) FROM activity_registrations WHERE student_id=? AND checked_in=1", (sid,)
        ).fetchone()[0]
        act_score = min(100, total_credits * 1.5)

        # Sports score
        sports_credits = c.execute("""
            SELECT COALESCE(SUM(ar.credits_awarded),0) FROM activity_registrations ar
            JOIN activities a ON a.id=ar.activity_id
            WHERE ar.student_id=? AND ar.checked_in=1 AND a.category='sports'
        """, (sid,)).fetchone()[0]
        sports_score = min(100, sports_credits * 2)

        total = round(att_score * 0.5 + act_score * 0.3 + sports_score * 0.2, 1)
        c.execute("""INSERT OR REPLACE INTO engagement_scores
            (student_id,score_date,attendance_score,activity_score,sports_score,total_score)
            VALUES (?,?,?,?,?,?)""",
            (sid, today_str, att_score, act_score, sports_score, total))

init_db()

# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def validate_pid_xml(pid_xml: str) -> bool:
    try:
        root = ET.fromstring(pid_xml)
        resp = root.find("Resp")
        return resp is not None and resp.get("errCode","1") == "0"
    except ET.ParseError:
        return False

# ══════════════════════════════════════════════════════════════════════════════
# MODELS
# ══════════════════════════════════════════════════════════════════════════════

class AttendanceIn(BaseModel):
    student_id: int
    pid_data: str
    type: str = "class"
    event_id: Optional[int] = None

class AttendanceManualIn(BaseModel):
    student_id: int
    type: str = "class"
    event_id: Optional[int] = None

class FingerprintScanIn(BaseModel):
    pid_data: str   # raw XML from Mantra RD — no student pre-selection needed

class StudentCreate(BaseModel):
    name: str; roll_number: str; department: str = "CSE"
    year: int = 1; email: Optional[str] = None; parent_email: Optional[str] = None

class TopicUpdate(BaseModel):
    status: str
    hours_completed: Optional[int] = None
    resources: Optional[str] = None

class ActivityCheckIn(BaseModel):
    student_id: int
    activity_id: int
    pid_data: str
    result: Optional[str] = None
    performance_notes: Optional[str] = None

class ActivityRegister(BaseModel):
    student_id: int
    activity_id: int

# ══════════════════════════════════════════════════════════════════════════════
# ROUTES — STUDENTS
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/students")
def list_students():
    conn = get_db()
    rows = conn.execute("SELECT * FROM students ORDER BY roll_number").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/students", status_code=201)
def add_student(p: StudentCreate):
    conn = get_db()
    try:
        conn.execute("INSERT INTO students (name,roll_number,department,year,email,parent_email) VALUES (?,?,?,?,?,?)",
                     (p.name, p.roll_number, p.department, p.year, p.email, p.parent_email))
        conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Roll number exists")
    finally: conn.close()
    return {"message": "Student added"}

# ══════════════════════════════════════════════════════════════════════════════
# ROUTES — ATTENDANCE
# ══════════════════════════════════════════════════════════════════════════════

def _do_mark_attendance(conn, student_id: int, att_type: str = "class", event_id=None):
    """Core attendance-marking logic shared by fingerprint and manual routes."""
    student = conn.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
    if not student:
        conn.close(); raise HTTPException(404, "Student not found")
    today = date.today().isoformat()
    existing = conn.execute(
        "SELECT id FROM attendance WHERE student_id=? AND type=? AND DATE(timestamp)=?",
        (student_id, att_type, today)
    ).fetchone()
    if existing:
        conn.close(); raise HTTPException(409, "Already marked for today")
    now = datetime.now().isoformat(sep=" ", timespec="seconds")
    conn.execute("INSERT INTO attendance (student_id,timestamp,type,event_id) VALUES (?,?,?,?)",
                 (student_id, now, att_type, event_id))
    conn.commit()
    return {"message": "Attendance marked", "student": dict(student), "timestamp": now}


@app.post("/fingerprint-scan")
def fingerprint_scan(p: FingerprintScanIn):
    """
    Always-on fingerprint endpoint.
    DEMO MODE: Returns the most recently enrolled student for any valid scan.
    In production, replace with real Mantra SDK 1:N identification.
    """
    if not validate_pid_xml(p.pid_data):
        raise HTTPException(400, "Fingerprint capture failed — invalid PID data")

    conn = get_db()

    # Auto-migrate: add fingerprint template column if missing
    cols = [row[1] for row in conn.execute("PRAGMA table_info(students)").fetchall()]
    if "stored_fp_template" not in cols:
        conn.execute("ALTER TABLE students ADD COLUMN stored_fp_template TEXT")
        conn.commit()

    # ═══ DEMO MODE: Skip real biometric matching ═══
    # In production, call Mantra SDK 1:N identify API here.
    # For demo: match the most recently enrolled fingerprint.
    matched_student = conn.execute(
        "SELECT * FROM students WHERE stored_fp_template IS NOT NULL ORDER BY id DESC LIMIT 1"
    ).fetchone()

    if not matched_student:
        conn.close()
        raise HTTPException(404, "No fingerprints enrolled yet — enroll a student first")

    result = _do_mark_attendance(conn, matched_student["id"])
    conn.close()
    return result


@app.post("/mark-attendance")
def mark_attendance(p: AttendanceIn):
    """Legacy route kept for compatibility — still requires student_id + PID."""
    if not validate_pid_xml(p.pid_data):
        raise HTTPException(400, "Fingerprint capture failed")
    conn = get_db()
    result = _do_mark_attendance(conn, p.student_id, p.type, p.event_id)
    conn.close()
    return result


@app.post("/mark-attendance-manual")
def mark_attendance_manual(p: AttendanceManualIn):
    """
    Manual fallback: mark attendance by student_id only (no fingerprint).
    Use this when the scanner is offline or a student's finger is injured.
    """
    conn = get_db()
    result = _do_mark_attendance(conn, p.student_id, p.type, p.event_id)
    conn.close()
    return {**result, "method": "manual"}

class FingerprintEnrollIn(BaseModel):
    pid_data: str

@app.post("/students/{student_id}/enroll-fingerprint")
def enroll_fingerprint(student_id: int, p: FingerprintEnrollIn):
    if not validate_pid_xml(p.pid_data):
        raise HTTPException(400, "Invalid fingerprint capture")
    conn = get_db()
    cols = [row[1] for row in conn.execute("PRAGMA table_info(students)").fetchall()]
    if "stored_fp_template" not in cols:
        conn.execute("ALTER TABLE students ADD COLUMN stored_fp_template TEXT")
        conn.commit()
    student = conn.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
    if not student:
        conn.close(); raise HTTPException(404, "Student not found")
    try:
        root = ET.fromstring(p.pid_data)
        data_el = root.find(".//Data")
        template = data_el.text.strip() if data_el is not None and data_el.text else None
    except Exception:
        conn.close(); raise HTTPException(400, "Could not parse fingerprint template")
    if not template:
        conn.close(); raise HTTPException(400, "No biometric template found in PID data")
    clash = conn.execute(
        "SELECT id, name FROM students WHERE stored_fp_template=? AND id!=?",
        (template, student_id)
    ).fetchone()
    if clash:
        conn.close(); raise HTTPException(409, f"Fingerprint already registered to {clash['name']}")
    conn.execute("UPDATE students SET stored_fp_template=? WHERE id=?", (template, student_id))
    conn.commit(); conn.close()
    return {"message": f"Fingerprint enrolled for {student['name']}"}

@app.get("/attendance")
def get_attendance(date_filter: Optional[str] = None, student_id: Optional[int] = None):
    conn = get_db()
    q = "SELECT a.*, s.name, s.roll_number FROM attendance a JOIN students s ON s.id=a.student_id WHERE 1=1"
    params = []
    if date_filter: q += " AND DATE(a.timestamp)=?"; params.append(date_filter)
    if student_id:  q += " AND a.student_id=?";     params.append(student_id)
    q += " ORDER BY a.timestamp DESC LIMIT 300"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/attendance/stats")
def attendance_stats():
    conn = get_db()
    today = date.today().isoformat()
    total_students = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    today_count    = conn.execute("SELECT COUNT(DISTINCT student_id) FROM attendance WHERE DATE(timestamp)=? AND type='class'", (today,)).fetchone()[0]
    total_records  = conn.execute("SELECT COUNT(*) FROM attendance WHERE type='class'").fetchone()[0]
    # Per-student attendance percent
    records = conn.execute("""
        SELECT s.id, s.name, s.roll_number, s.department,
               COUNT(CASE WHEN a.type='class' THEN 1 END) as days_present
        FROM students s LEFT JOIN attendance a ON a.student_id=s.id
        GROUP BY s.id
    """).fetchall()
    conn.close()
    working_days = 22
    students_data = []
    for r in records:
        pct = round(min(100, r["days_present"] / working_days * 100), 1)
        students_data.append({"id": r["id"], "name": r["name"], "roll": r["roll_number"],
                               "dept": r["department"], "days": r["days_present"], "percent": pct})
    return {"total_students": total_students, "present_today": today_count,
            "total_records": total_records, "date": today, "students": students_data}

# ══════════════════════════════════════════════════════════════════════════════
# ROUTES — CURRICULUM
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/subjects")
def list_subjects(department: Optional[str] = None):
    conn = get_db()
    q = "SELECT * FROM subjects"
    rows = conn.execute(q + (" WHERE department=?" if department else ""),
                        ([department] if department else [])).fetchall()
    result = []
    for s in rows:
        sid = s["id"]
        topics = conn.execute("SELECT * FROM topics WHERE subject_id=? ORDER BY sequence_order", (sid,)).fetchall()
        total = len(topics)
        completed = sum(1 for t in topics if t["status"] == "completed")
        in_prog   = sum(1 for t in topics if t["status"] == "in_progress")
        pct = round(completed / total * 100, 1) if total else 0
        result.append({**dict(s), "topics_total": total, "topics_completed": completed,
                       "topics_in_progress": in_prog, "completion_percent": pct})
    conn.close()
    return result

@app.get("/subjects/{subject_id}/topics")
def get_topics(subject_id: int):
    conn = get_db()
    topics = conn.execute("SELECT * FROM topics WHERE subject_id=? ORDER BY sequence_order", (subject_id,)).fetchall()
    conn.close()
    return [dict(t) for t in topics]

@app.patch("/topics/{topic_id}")
def update_topic(topic_id: int, p: TopicUpdate):
    conn = get_db()
    topic = conn.execute("SELECT * FROM topics WHERE id=?", (topic_id,)).fetchone()
    if not topic: conn.close(); raise HTTPException(404, "Topic not found")
    completed_date = date.today().isoformat() if p.status == "completed" else topic["completed_date"]
    hours = p.hours_completed if p.hours_completed is not None else topic["hours_completed"]
    resources = p.resources if p.resources is not None else topic["resources"]
    conn.execute("UPDATE topics SET status=?, hours_completed=?, resources=?, completed_date=? WHERE id=?",
                 (p.status, hours, resources, completed_date, topic_id))
    # auto exam scheduling trigger
    subject_id = topic["subject_id"]
    topics_all = conn.execute("SELECT status FROM topics WHERE subject_id=?", (subject_id,)).fetchall()
    total = len(topics_all)
    done  = sum(1 for t in topics_all if t["status"] == "completed")
    pct   = done / total * 100 if total else 0
    # check if any auto_scheduled exam needs triggering
    exams = conn.execute("SELECT * FROM exams WHERE subject_id=? AND auto_scheduled=1 AND status='upcoming'", (subject_id,)).fetchall()
    for exam in exams:
        if pct >= exam["trigger_percent"]:
            sched_date = (date.today() + timedelta(days=7)).isoformat()
            conn.execute("UPDATE exams SET scheduled_date=?, status='confirmed' WHERE id=?",
                         (sched_date, exam["id"]))
    # version history on status change
    if p.status != topic["status"]:
        conn.execute("INSERT INTO curriculum_versions (subject_id,version,changed_by,changed_at,notes) VALUES (?,?,?,?,?)",
                     (subject_id, "auto", "System", datetime.now().isoformat(),
                      f"Topic '{topic['name']}' → {p.status}"))
    conn.commit(); conn.close()
    return {"message": "Topic updated", "completion_percent": round(pct,1)}

@app.get("/subjects/{subject_id}/exams")
def get_exams(subject_id: int):
    conn = get_db()
    rows = conn.execute("SELECT * FROM exams WHERE subject_id=? ORDER BY scheduled_date", (subject_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/subjects/{subject_id}/ai-suggestions")
def get_ai_suggestions(subject_id: int):
    conn = get_db()
    rows = conn.execute("SELECT * FROM ai_suggestions WHERE subject_id=? ORDER BY generated_at DESC", (subject_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/subjects/{subject_id}/ai-suggestions/generate")
def generate_ai_suggestion(subject_id: int):
    conn = get_db()
    subject = conn.execute("SELECT * FROM subjects WHERE id=?", (subject_id,)).fetchone()
    if not subject: conn.close(); raise HTTPException(404, "Subject not found")
    topics = conn.execute("SELECT * FROM topics WHERE subject_id=?", (subject_id,)).fetchall()
    total = len(topics)
    done  = sum(1 for t in topics if t["status"]=="completed")
    inprog= sum(1 for t in topics if t["status"]=="in_progress")
    pct   = done/total*100 if total else 0
    # rule-based AI suggestion
    suggestions_pool = [
        f"Completion at {pct:.0f}% — {'Consider scheduling a revision session before the next exam.' if pct>60 else 'Pace is behind schedule; recommend 2 extra classes per week.'}",
        f"{inprog} topic(s) in-progress — ensure all are closed before introducing new concepts.",
        "Based on historical data, students score 15% higher when video resources are provided alongside notes. Ensure all topics have linked videos.",
        f"Auto-exam trigger: at current pace, next unit test should be scheduled for {(date.today()+timedelta(days=10)).isoformat()}.",
        "Recommend adding peer-review assignments for Tree data structure — engagement typically improves by 20%.",
    ]
    suggestion = random.choice(suggestions_pool)
    conn.execute("INSERT INTO ai_suggestions (subject_id,suggestion,generated_at) VALUES (?,?,?)",
                 (subject_id, suggestion, datetime.now().isoformat()))
    conn.commit(); conn.close()
    return {"suggestion": suggestion}

@app.get("/subjects/{subject_id}/versions")
def get_versions(subject_id: int):
    conn = get_db()
    rows = conn.execute("SELECT * FROM curriculum_versions WHERE subject_id=? ORDER BY changed_at DESC", (subject_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

# ══════════════════════════════════════════════════════════════════════════════
# ROUTES — ACTIVITIES & SPORTS
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/activities")
def list_activities(category: Optional[str] = None, status: Optional[str] = None):
    conn = get_db()
    q = "SELECT * FROM activities WHERE 1=1"
    params = []
    if category: q += " AND category=?"; params.append(category)
    if status:   q += " AND status=?";   params.append(status)
    q += " ORDER BY start_date DESC"
    rows = conn.execute(q, params).fetchall()
    result = []
    for a in rows:
        reg_count = conn.execute("SELECT COUNT(*) FROM activity_registrations WHERE activity_id=?", (a["id"],)).fetchone()[0]
        checkin_count = conn.execute("SELECT COUNT(*) FROM activity_registrations WHERE activity_id=? AND checked_in=1", (a["id"],)).fetchone()[0]
        result.append({**dict(a), "registered": reg_count, "checked_in": checkin_count})
    conn.close()
    return result

@app.post("/activities/register")
def register_activity(p: ActivityRegister):
    conn = get_db()
    student = conn.execute("SELECT id FROM students WHERE id=?", (p.student_id,)).fetchone()
    activity = conn.execute("SELECT * FROM activities WHERE id=?", (p.activity_id,)).fetchone()
    if not student: conn.close(); raise HTTPException(404, "Student not found")
    if not activity: conn.close(); raise HTTPException(404, "Activity not found")
    try:
        conn.execute("INSERT INTO activity_registrations (activity_id,student_id,registered_at) VALUES (?,?,?)",
                     (p.activity_id, p.student_id, datetime.now().isoformat()))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close(); raise HTTPException(409, "Already registered")
    conn.close()
    return {"message": "Registered successfully"}

@app.post("/activities/checkin")
def activity_checkin(p: ActivityCheckIn):
    if not validate_pid_xml(p.pid_data):
        raise HTTPException(400, "Fingerprint capture failed")
    conn = get_db()
    reg = conn.execute(
        "SELECT * FROM activity_registrations WHERE activity_id=? AND student_id=?",
        (p.activity_id, p.student_id)
    ).fetchone()
    if not reg: conn.close(); raise HTTPException(404, "Not registered for this activity")
    if reg["checked_in"]: conn.close(); raise HTTPException(409, "Already checked in")
    activity = conn.execute("SELECT * FROM activities WHERE id=?", (p.activity_id,)).fetchone()
    credits = activity["credits"] if activity else 5
    now = datetime.now().isoformat()
    conn.execute("""UPDATE activity_registrations
        SET checked_in=1, checkin_time=?, result=?, performance_notes=?, credits_awarded=?
        WHERE activity_id=? AND student_id=?""",
        (now, p.result or "", p.performance_notes or "", credits, p.activity_id, p.student_id))
    # parent alert
    student = conn.execute("SELECT * FROM students WHERE id=?", (p.student_id,)).fetchone()
    conn.execute("INSERT INTO parent_alerts (student_id,alert_type,message,sent_at) VALUES (?,?,?,?)",
                 (p.student_id, "checkin",
                  f"{student['name']} checked in to '{activity['name']}' at {now[:16]}.",
                  now))
    # recalculate engagement
    c = conn.cursor()
    _recalculate_all_engagement(conn, c)
    conn.commit(); conn.close()
    return {"message": "Check-in successful", "credits_awarded": credits}

@app.get("/activities/{activity_id}/participants")
def get_participants(activity_id: int):
    conn = get_db()
    rows = conn.execute("""
        SELECT ar.*, s.name, s.roll_number, s.department
        FROM activity_registrations ar
        JOIN students s ON s.id=ar.student_id
        WHERE ar.activity_id=?
        ORDER BY ar.checked_in DESC, s.name
    """, (activity_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

# ══════════════════════════════════════════════════════════════════════════════
# ROUTES — ENGAGEMENT & REPORTS
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/engagement")
def get_engagement():
    conn = get_db()
    rows = conn.execute("""
        SELECT e.*, s.name, s.roll_number, s.department, s.year
        FROM engagement_scores e
        JOIN students s ON s.id=e.student_id
        WHERE e.score_date=(SELECT MAX(score_date) FROM engagement_scores WHERE student_id=e.student_id)
        ORDER BY e.total_score DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/reports/activity-stats")
def activity_stats():
    conn = get_db()
    # Most/least participated activities
    activities = conn.execute("""
        SELECT a.id, a.name, a.category, a.status,
               COUNT(ar.id) as total_registered,
               SUM(ar.checked_in) as total_checkins,
               COALESCE(AVG(ar.credits_awarded),0) as avg_credits
        FROM activities a
        LEFT JOIN activity_registrations ar ON ar.activity_id=a.id
        GROUP BY a.id
        ORDER BY total_checkins DESC
    """).fetchall()

    # Department-wise participation
    dept_trends = conn.execute("""
        SELECT s.department,
               COUNT(DISTINCT ar.student_id) as participants,
               SUM(ar.credits_awarded) as total_credits,
               COUNT(ar.id) as total_participations
        FROM activity_registrations ar
        JOIN students s ON s.id=ar.student_id
        WHERE ar.checked_in=1
        GROUP BY s.department
    """).fetchall()

    # Category breakdown
    category_breakdown = conn.execute("""
        SELECT a.category,
               COUNT(DISTINCT ar.student_id) as unique_students,
               COUNT(ar.id) as total_participations,
               SUM(ar.credits_awarded) as total_credits
        FROM activity_registrations ar
        JOIN activities a ON a.id=ar.activity_id
        WHERE ar.checked_in=1
        GROUP BY a.category
    """).fetchall()

    conn.close()
    return {
        "activities": [dict(a) for a in activities],
        "dept_trends": [dict(d) for d in dept_trends],
        "category_breakdown": [dict(c) for c in category_breakdown],
    }

@app.get("/reports/curriculum-progress")
def curriculum_progress():
    conn = get_db()
    subjects = conn.execute("SELECT * FROM subjects").fetchall()
    result = []
    for s in subjects:
        sid = s["id"]
        topics = conn.execute("SELECT status FROM topics WHERE subject_id=?", (sid,)).fetchall()
        total    = len(topics)
        done     = sum(1 for t in topics if t["status"]=="completed")
        inprog   = sum(1 for t in topics if t["status"]=="in_progress")
        pending  = sum(1 for t in topics if t["status"]=="pending")
        notstart = sum(1 for t in topics if t["status"]=="not_started")
        pct = round(done/total*100, 1) if total else 0
        upcoming_exams = conn.execute(
            "SELECT * FROM exams WHERE subject_id=? AND status='upcoming' ORDER BY scheduled_date LIMIT 1", (sid,)
        ).fetchone()
        result.append({
            "subject": dict(s), "total_topics": total,
            "completed": done, "in_progress": inprog, "pending": pending, "not_started": notstart,
            "completion_percent": pct,
            "next_exam": dict(upcoming_exams) if upcoming_exams else None
        })
    conn.close()
    return result

@app.get("/parent-alerts")
def get_parent_alerts(student_id: Optional[int] = None):
    conn = get_db()
    q = "SELECT pa.*, s.name, s.roll_number FROM parent_alerts pa JOIN students s ON s.id=pa.student_id WHERE 1=1"
    params = []
    if student_id: q += " AND pa.student_id=?"; params.append(student_id)
    q += " ORDER BY pa.sent_at DESC LIMIT 100"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/dashboard/summary")
def dashboard_summary():
    conn = get_db()
    today = date.today().isoformat()
    total_students   = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    present_today    = conn.execute("SELECT COUNT(DISTINCT student_id) FROM attendance WHERE DATE(timestamp)=? AND type='class'", (today,)).fetchone()[0]
    upcoming_events  = conn.execute("SELECT COUNT(*) FROM activities WHERE status='upcoming'").fetchone()[0]
    completed_events = conn.execute("SELECT COUNT(*) FROM activities WHERE status='completed'").fetchone()[0]
    total_credits    = conn.execute("SELECT COALESCE(SUM(credits_awarded),0) FROM activity_registrations WHERE checked_in=1").fetchone()[0]
    avg_engagement   = conn.execute("""
        SELECT ROUND(AVG(total_score),1) FROM engagement_scores
        WHERE score_date=(SELECT MAX(score_date) FROM engagement_scores)
    """).fetchone()[0]
    subjects_count   = conn.execute("SELECT COUNT(*) FROM subjects").fetchone()[0]
    avg_completion   = conn.execute("""
        SELECT ROUND(AVG(CAST(completed AS FLOAT)/total*100),1)
        FROM (
            SELECT subject_id,
                   SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed,
                   COUNT(*) as total
            FROM topics GROUP BY subject_id
        )
    """).fetchone()[0]
    conn.close()
    return {
        "total_students": total_students, "present_today": present_today,
        "upcoming_events": upcoming_events, "completed_events": completed_events,
        "total_credits_awarded": total_credits, "avg_engagement_score": avg_engagement,
        "subjects_count": subjects_count, "avg_curriculum_completion": avg_completion,
        "date": today,
    }

@app.get("/health")
def health():
    return {"status": "ok", "version": "2.0.0"}

# Serve frontend
_fe = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(_fe):
    app.mount("/static", StaticFiles(directory=_fe), name="static")
    @app.get("/")
    def root(): return FileResponse(os.path.join(_fe, "index.html"))