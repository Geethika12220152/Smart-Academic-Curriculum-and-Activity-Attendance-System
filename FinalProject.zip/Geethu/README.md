# EduPlatform — Academic & Sports Management System
### FastAPI · SQLite · Mantra RD Service · Vanilla JS

---

## Quick Start

```bash
# 1. Install
pip install -r requirements.txt

# 2. Start Mantra RD Service (localhost:11100)

# 3. Run backend (auto-seeds all demo data)
cd backend
uvicorn main:app --reload --port 8000

# 4. Open → http://127.0.0.1:8000
```

---

## Modules

| Module | Features |
|---|---|
| **Dashboard** | Live stats, attendance trend, top performers, upcoming events |
| **Attendance** | Biometric class mark-in, per-student % tracking, daily records |
| **Curriculum** | Topic status tracker, AI suggestions, version history, resource links |
| **Exam Schedule** | Auto-scheduled exams triggered by curriculum % completion |
| **Activities & Sports** | 8 events (cricket, football, coding club, etc.) with credits |
| **Event Check-In** | Biometric check-in for any activity, parent alert on entry |
| **Engagement Scores** | Composite score: Attendance×0.5 + Activity×0.3 + Sports×0.2 |
| **Analytics** | Charts: participation, dept-wise trends, curriculum progress |
| **Parent Alerts** | Achievement wins + absence alerts auto-generated |

---

## Demo Data Preloaded

**Students:** Amit Sharma (101), Priya Verma (102) + 8 more  
**Subjects:** DSA, DBMS, OS, Circuit Theory, Engineering Math  
**Topics (DSA):** Arrays ✅, Linked Lists ✅, Stacks ✅, Trees 🔄, Heaps ⏳, Graphs ⭕, DP ⭕  
**Activities:** Cricket Match, Football Tournament, Coding Club, Badminton, NSS Camp, Tech Talk  
**AI Suggestions:** 4 pre-generated + generate-on-demand  
**Exams:** 5 scheduled (2 auto-triggered at 70% completion)  
**Attendance:** 30 days of history for all 10 students  

---

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| GET | `/dashboard/summary` | Dashboard KPIs |
| GET/POST | `/students` | List / add students |
| POST | `/mark-attendance` | Biometric class attendance |
| GET | `/attendance/stats` | Per-student % breakdown |
| GET | `/subjects` | Subjects with completion % |
| GET | `/subjects/{id}/topics` | Topic list with status |
| PATCH | `/topics/{id}` | Update topic status (triggers exam auto-scheduling) |
| GET/POST | `/subjects/{id}/ai-suggestions` | Get / generate AI suggestions |
| GET | `/subjects/{id}/versions` | Curriculum version history |
| GET | `/activities` | All activities (filterable by category/status) |
| POST | `/activities/checkin` | Biometric activity check-in |
| GET | `/engagement` | Student engagement leaderboard |
| GET | `/reports/activity-stats` | Participation + dept trends |
| GET | `/reports/curriculum-progress` | Subject-wise progress |
| GET | `/parent-alerts` | All parent alerts |

---

## Engagement Score Formula

```
Total Score = (Attendance Score × 0.5) + (Activity Score × 0.3) + (Sports Score × 0.2)

Attendance Score = min(100, days_present × 5)
Activity Score   = min(100, total_activity_credits × 1.5)
Sports Score     = min(100, total_sports_credits × 2.0)
```

Grades: A+ ≥85 · A ≥70 · B ≥55 · C ≥40 · D <40

---

## Project Structure

```
edu-platform/
├── backend/
│   └── main.py          # All FastAPI routes + DB init + seeding
├── frontend/
│   └── index.html       # Full SPA with Chart.js dashboards
├── database/
│   └── edu.db           # Auto-created SQLite DB
├── requirements.txt
└── README.md
```
